session1 5 commands in the order 11 22 33 44 55
session 2 2 commands in the order 55 22
session 3 3 commands in the order 55 33 44 
